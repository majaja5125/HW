package com.hiwin.gripper.impl;

import java.util.Collection;
import java.util.Iterator;

import com.ur.urcap.api.contribution.ProgramNodeContribution;
import com.ur.urcap.api.contribution.ProgramNodeService;
import com.ur.urcap.api.domain.ApplicationAPI;
import com.ur.urcap.api.domain.SystemAPI;
import com.ur.urcap.api.domain.URCapAPI;
import com.ur.urcap.api.domain.data.DataModel;
import com.ur.urcap.api.domain.io.DigitalIO;
import com.ur.urcap.api.domain.io.IOFilterFactory;
import com.ur.urcap.api.domain.program.ProgramModel;
import com.ur.urcap.api.domain.program.nodes.ProgramNodeFactory;
import com.ur.urcap.api.domain.program.nodes.builtin.InvalidDomainException;
import com.ur.urcap.api.domain.program.nodes.builtin.SetNode;
import com.ur.urcap.api.domain.program.nodes.builtin.configurations.setnode.*;
import com.ur.urcap.api.domain.program.structure.TreeNode;
import com.ur.urcap.api.domain.program.structure.TreeStructureException;
import com.ur.urcap.api.domain.script.ScriptWriter;
import com.ur.urcap.api.ui.annotation.Input;
import com.ur.urcap.api.ui.component.InputButton;
import com.ur.urcap.api.ui.component.InputEvent;

public class GripperProgramNodeContribution implements ProgramNodeContribution {

	private final URCapAPI urCapAPI;
	private final DataModel dataModel;
	

	private final String BUTTON_GRIPPER0 = "buttonGripper0";
	private final String BUTTON_GRIPPER1 = "buttonGripper1";
	private final String BUTTON_GRIPPER2 = "buttonGripper2";
	private final String BUTTON_GRIPPER3 = "buttonGripper3";
	private final String BUTTON_GRIPPER4 = "buttonGripper4";
	private final String BUTTON_GRIPPER5 = "buttonGripper5";

	private final String BUTTON_RESET_TEMPLATE = "buttonResetTemplate";
	private final String BUTTON_GRIP_TEMPLATE_ID = "buttonGripTemplate";
	private final String BUTTON_RELEASE_TEMPLATE_ID = "buttonReleaseTemplate";

	private final String TEMPLATE_NONE = "Hiwin Gripper";
	private final String TEMPLATE_GRIP = "Grip";
	private final String TEMPLATE_RELEASE = "Release";
	private final String GRIPPER_ID = "gripperID";
	private final String IS_GRIP = "gripType";

	@Input(id = BUTTON_GRIPPER0)
	public InputButton buttonGripper0;

	@Input(id = BUTTON_GRIPPER1)
	public InputButton buttonGripper1;

	@Input(id = BUTTON_GRIPPER2)
	public InputButton buttonGripper2;

	@Input(id = BUTTON_GRIPPER3)
	public InputButton buttonGripper3;

	@Input(id = BUTTON_GRIPPER4)
	public InputButton buttonGripper4;

	@Input(id = BUTTON_GRIPPER5)
	public InputButton buttonGripper5;

	
	@Input(id = BUTTON_RESET_TEMPLATE)
	public InputButton buttonResetTemplate;

	@Input(id = BUTTON_GRIP_TEMPLATE_ID)
	public InputButton buttonGripTemplate;

	@Input(id = BUTTON_RELEASE_TEMPLATE_ID)
	public InputButton buttonReleaseTemplate;

	public GripperProgramNodeContribution(URCapAPI urCapAPI, DataModel dataModel) {
		this.urCapAPI = urCapAPI;
		this.dataModel = dataModel;
	}


	@Input(id = BUTTON_GRIPPER0)
	public void onButtonGripper0(InputEvent event) {
		if (event.getEventType() == InputEvent.EventType.ON_PRESSED) {
			dataModel.set(GRIPPER_ID, buttonGripper0.getText());
			updateView();
		}
	}

	@Input(id = BUTTON_GRIPPER1)
	public void onButtonGripper1(InputEvent event) {
		if (event.getEventType() == InputEvent.EventType.ON_PRESSED) {
			dataModel.set(GRIPPER_ID, buttonGripper1.getText());
			updateView();
		}
	}

	@Input(id = BUTTON_GRIPPER2)
	public void onButtonGripper2(InputEvent event) {
		if (event.getEventType() == InputEvent.EventType.ON_PRESSED) {
			dataModel.set(GRIPPER_ID, buttonGripper2.getText());
			updateView();
		}
	}

	@Input(id = BUTTON_GRIPPER3)
	public void onButtonGripper3(InputEvent event) {
		if (event.getEventType() == InputEvent.EventType.ON_PRESSED) {
			dataModel.set(GRIPPER_ID, buttonGripper3.getText());
			updateView();
		}
	}

	@Input(id = BUTTON_GRIPPER4)
	public void onButtonGripper4(InputEvent event) {
		if (event.getEventType() == InputEvent.EventType.ON_PRESSED) {
			dataModel.set(GRIPPER_ID, buttonGripper4.getText());
			updateView();
		}
	}

	@Input(id = BUTTON_GRIPPER5)
	public void onButtonGripper5(InputEvent event) {
		if (event.getEventType() == InputEvent.EventType.ON_PRESSED) {
			dataModel.set(GRIPPER_ID, buttonGripper5.getText());
			updateView();
		}
	}
	

	@Input(id = BUTTON_RESET_TEMPLATE)
	public void onButtonResetTemplateTap(InputEvent event) {
		if (event.getEventType() == InputEvent.EventType.ON_PRESSED) {
			dataModel.set(IS_GRIP, TEMPLATE_NONE);
			clearSubtree();
			updateView();
		}
	}

	@Input(id = BUTTON_GRIP_TEMPLATE_ID)
	public void onButtonPickTemplateTap(InputEvent event) {
		if (event.getEventType() == InputEvent.EventType.ON_PRESSED) {
			dataModel.set(IS_GRIP, TEMPLATE_GRIP);
			// createSubtree(TEMPLATE_GRIP);
			updateView();
		}
	}

	@Input(id = BUTTON_RELEASE_TEMPLATE_ID)
	public void onButtonPlaceTemplateTap(InputEvent event) {
		if (event.getEventType() == InputEvent.EventType.ON_PRESSED) {
			dataModel.set(IS_GRIP, TEMPLATE_RELEASE);
			// createSubtree(TEMPLATE_RELEASE);
			updateView();
		}
	}

	
	DigitalIO o1;
	DigitalOutputSetNodeConfig ss;
	SetNodeConfig config;
	private void addGripper(String template, TreeNode root, ProgramNodeFactory nf) throws TreeStructureException {
		SetNode s =	nf.createSetNode();
		
	
		config = ss;
		SystemAPI sapi;
		Collection<DigitalIO> IOC = urCapAPI.getIOs().getIOs(DigitalIO.class); 
		int iocnt = IOC.size();
		
		Iterator<DigitalIO> IOC_itr = IOC.iterator();
		while(IOC_itr.hasNext()) {
			DigitalIO io = IOC_itr.next();
			if("digital_out[0]".equals(io.getDefaultName())) {
				o1 = io;
				break;
			}
			
		}
		System.out.println(o1.getDefaultName());
		
		//o1.setValue(true);
		;
		

		
		try {
			s.setConfig(s.getConfigFactory().createDigitalOutputConfig(o1, true));
		} catch (InvalidDomainException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//DigitalIO DigitalIO;
		//s.getConfigFactory().createDigitalOutputConfig(DigitalIO d , true);
		//s.getConfigFactory().createDigitalOutputConfig(DigitalOutputSelection.SelectionType.DIGITAL_OUTPUT, true);
		
		//DigitalIO ccc = null;
		
	
	//	try {
		//	s.setConfig(cdd);
	//	} catch (InvalidDomainException e) {
			// TODO Auto-generated catch block
	//		e.printStackTrace();
	//	}
		root.addChild(s);
	}

	private int childrenCount(){
		return urCapAPI.getProgramModel().getRootTreeNode(this).getChildren().size();
	}

	private void clearSubtree(){
		dataModel.remove(GRIPPER_ID);
		dataModel.remove(IS_GRIP);
		
		
		
//		TreeNode tree = urCapAPI.getProgramModel().getRootTreeNode(this);
//		int size = childrenCount();
//		try {
//			for (int i = 0; i < size; i++) {
//				tree.removeChild(tree.getChildren().get(0));
//			}
//		} catch (TreeStructureException e) {
//			// See e.getMessage() for explanation
//		}
	}

	private void createSubtree(String template) {
		ProgramModel programModel = urCapAPI.getProgramModel();
		ProgramNodeFactory nf = programModel.getProgramNodeFactory();
		
	
		TreeNode root = programModel.getRootTreeNode(this);
		root.setChildSequenceLocked(true);

		try {
			addGripper(template, root, nf);

			//TreeNode folderRetract = root.addChild(nf.createFolderNode());
			//folderRetract.addChild(nf.createCommentNode().setComment("Please customize your functionality here"));
		} catch (TreeStructureException e) {
			// See e.getMessage() for explanation
		}
	}

	private void updateView(){
		boolean choosedGripper= dataModel.get(GRIPPER_ID, TEMPLATE_NONE) != TEMPLATE_NONE;
		buttonGripper0.setEnabled(!choosedGripper);
		buttonGripper1.setEnabled(!choosedGripper);
		buttonGripper2.setEnabled(!choosedGripper);
		buttonGripper3.setEnabled(!choosedGripper);
		buttonGripper4.setEnabled(!choosedGripper);
		buttonGripper5.setEnabled(!choosedGripper);
		
		boolean choosedType= dataModel.get(IS_GRIP, "") != "";
	
		buttonResetTemplate.setEnabled(choosedGripper || choosedType);
		buttonGripTemplate.setEnabled(!choosedType);
		buttonReleaseTemplate.setEnabled(!choosedType);
		
		TreeNode root = urCapAPI.getProgramModel().getRootTreeNode(this);
		root.setChildSequenceLocked(choosedGripper || choosedType);
		
	}

	@Override
	public void openView() {
		updateView();
	}

	@Override
	public void closeView() {
	}

	@Override
	public String getTitle() {
		return dataModel.get(GRIPPER_ID, TEMPLATE_NONE) + " " + dataModel.get(IS_GRIP, "");
	}

	@Override
	public boolean isDefined() {
		return dataModel.get(GRIPPER_ID, "") != "" && dataModel.get(IS_GRIP, "") != "";
	}

	@Override
	public void generateScript(ScriptWriter writer) {
		// writer.writeChildren();
		System.out.println(getTitle());
	}

}
