package com.hiwin.gripper.impl;

import com.ur.urcap.api.contribution.InstallationNodeContribution;
import com.ur.urcap.api.contribution.InstallationNodeService;
import com.ur.urcap.api.domain.URCapAPI;

import java.io.InputStream;

import com.ur.urcap.api.domain.data.DataModel;

public class GripperInstallationNodeService implements InstallationNodeService {

	public GripperInstallationNodeService() { }

	@Override
	public InstallationNodeContribution createInstallationNode(URCapAPI api, DataModel model) {
		return new GripperInstallationNodeContribution(api,model);
	}

	
	
	@Override
	public String getTitle() {
		return "Hiwin Gripper";
	}

	@Override
	public InputStream getHTML() {
		InputStream is = this.getClass().getResourceAsStream("/Installation.html");
		return is;
	}
}
