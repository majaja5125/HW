package com.hiwin.gripper.impl;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Vector;

import com.ur.urcap.api.contribution.InstallationNodeContribution;
import com.ur.urcap.api.domain.ApplicationAPI;
import com.ur.urcap.api.domain.URCapAPI;
import com.ur.urcap.api.domain.data.DataModel;
import com.ur.urcap.api.domain.io.IO;
import com.ur.urcap.api.domain.io.IOFilterFactory;
import com.ur.urcap.api.domain.io.IOModel;
import com.ur.urcap.api.domain.script.ScriptWriter;
import com.ur.urcap.api.domain.value.simple.Length;
import com.ur.urcap.api.domain.variable.Variable;
import com.ur.urcap.api.ui.annotation.Input;
import com.ur.urcap.api.ui.annotation.Select;
import com.ur.urcap.api.ui.component.InputEvent;
import com.ur.urcap.api.ui.component.InputTextField;
import com.ur.urcap.api.ui.component.SelectDropDownList;
import com.ur.urcap.api.ui.component.SelectEvent;

public class GripperInstallationNodeContribution implements InstallationNodeContribution {

	private static final int GripNum = 5;
	private static final String UNIT = "unit";
	
	
	private DataModel model;
	private URCapAPI api;
	public GripperInstallationNodeContribution( URCapAPI api,DataModel model) {
		this.model = model;
		this.api = api;
	}

	@Select(id = "gripperid")
	private SelectDropDownList gripIdDropDown;
	@Select(id = "outputReady")
	private SelectDropDownList readyDropDown;
	@Select(id = "outputDirection")
	private SelectDropDownList dirDropDown;
	@Select(id = "inputBusy")
	private SelectDropDownList busyDropDown;
	@Select(id = "inputAlarm")
	private SelectDropDownList alarmDropDown;
	
	
	
	
	@Override
	public void openView() {
//		popupTitleField.setText(getPopupTitle());
		initializeDropDownList();
	}

	Variable a ;
	private void initializeDropDownList() {
		List<String> gripperList = new Vector<String>();
		for(int i = 0 ; i <GripNum;i++) {
			gripperList.add("Gripper[" + i + "]");
		}
		gripIdDropDown.setItems(gripperList);

		Collection<IO> ios = api.getIOs().getIOs();

		List<String> intput = new Vector<String>();
		List<String> outtput = new Vector<String>();
		
		for(IO io: ios) {
			if( IOFilterFactory.digitalInputFilter().accept(io)) {
				intput.add((io.getName()));
			}else if(IOFilterFactory.digitalOutputFilter().accept(io)) {
				outtput.add((io.getName()));
			}
		}

		readyDropDown.setItems(outtput);
		dirDropDown.setItems(outtput);
		busyDropDown.setItems(intput);
		alarmDropDown.setItems(intput);
		
		
		
//		final Length.Unit targetUnit = getTargetUnit();
//		for (TranslatableLengthUnit unit : unitNames) {
//			if (unit.getUnit() == targetUnit) {
//				gripIdDropDown.selectItem(unit);
//				return;
//			}
//		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	private int getTargetUnit() {
		return 0;
	}
//	@Select(id = "gripperid")
//	public void encoderTypeSelected(SelectEvent event) {
//		if (event.getEvent() == SelectEvent.EventType.ON_SELECT) {
//			final Length.Unit targetUnit = ((TranslatableLengthUnit) conversionUnitDropDown.getSelectedItem()).getUnit();
//			model.set(UNIT, targetUnit.name());
//			setUnitExampleLabel();
//		}
//	}
	
	
//	private static final String POPUPTITLE_KEY = "popuptitle";
//	private static final String DEFAULT_VALUE = "Hello World";
//

//
//	@Input(id = POPUPTITLE_KEY)
//	private InputTextField popupTitleField;
//
//	@Input(id = POPUPTITLE_KEY)
//	public void onMessageChange(InputEvent event) {
//		if (event.getEventType() == InputEvent.EventType.ON_CHANGE) {
//			setPopupTitle(popupTitleField.getText());
//		}
//	}

	

	
	
	
	
	
	@Override
	public void closeView() { }

//	public boolean isDefined() {
//		return !getPopupTitle().isEmpty();
//	}

	@Override
	public void generateScript(ScriptWriter writer) {
		// Store the popup title in a global variable so it is globally available to all HelloWorld program nodes.
		//writer.assign("hello_world_popup_title", "\"" + getPopupTitle() + "\"");
	}

//	public String getPopupTitle() {
//		return model.get(POPUPTITLE_KEY, DEFAULT_VALUE);
//	}

//	private void setPopupTitle(String message) {
//		if ("".equals(message)) {
//			resetToDefaultValue();
//		} else {
//			model.set(POPUPTITLE_KEY, message);
//		}
//	}
//
//	private void resetToDefaultValue() {
//		popupTitleField.setText(DEFAULT_VALUE);
//		model.set(POPUPTITLE_KEY, DEFAULT_VALUE);
//	}
}
