package com.hiwin.gripper.impl;

import com.ur.urcap.api.contribution.ProgramNodeContribution;
import com.ur.urcap.api.contribution.ProgramNodeService;
import com.ur.urcap.api.domain.URCapAPI;
import com.ur.urcap.api.domain.data.DataModel;

import java.io.InputStream;

public class GripperProgramNodeService implements ProgramNodeService {

	@Override
	public String getId() {
		return "HiwinGripperProgramNode";
	}

	@Override
	public String getTitle() {
		return "Hiwin Gripper";
	}

	@Override
	public InputStream getHTML() {
		return this.getClass().getResourceAsStream("/GripperProgramNode.html");
	}

	@Override
	public boolean isDeprecated() {
		return false;
	}

	@Override
	public boolean isChildrenAllowed() {
		return false;
	}

	@Override
	public ProgramNodeContribution createNode(URCapAPI urCapAPI, DataModel dataModel) {
		return new GripperProgramNodeContribution(urCapAPI, dataModel);
	}
}
